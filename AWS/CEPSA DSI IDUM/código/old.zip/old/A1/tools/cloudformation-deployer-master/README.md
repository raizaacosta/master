# cloudformation-deployer Tool

This tool will provide a simple method to deploy cloudformation templates with a unified __yaml__ configuration file.

# Current Version 1.1.14

# Installation

To install clone this repo in some path (i.e. ~ or /opt) and link the __cloudformation_deploy__ tool to our **/usr/bin/** or **/home/${USER}/.local/bin/**, so in future updates of the tool you just git pull.

``` shell
$ git clone https://servidor0008.cepsacorp.com/devops-tools/cloudformation-deployer.git ~/cloudformation-deployer
$ mkdir -p /home/${USER}/.local/bin/
$ sudo ln -s /home/ec2-user/cloudformation-deployer/cloudformation_deploy.py /home/${USER}/.local/bin/cloudformation-deployer
or
$ sudo ln -s /home/ec2-user/cloudformation-deployer/cloudformation_deploy.py /usr/bin/cloudformation-deployer

```

This program is made with python3 and you must install the following dependencies in your cloud9:

``` shell
$ python3 -m pip install --user -r requirements.txt
```

if you have problems with the gitdb version please try to force the version to 2.0.3 with the following command (or change pip to pip3 depending on your python version)
``` bash
$ pip install --upgrade gitdb2=2.0.6
or
$ pip3 install --upgrade gitdb2=2.0.6
or
$ pip-3.6 install --upgrade gitdb2=2.0.6

```


# Usage

This tool is a CLI, that can be invoked direclty in the shellscript, if you specify the __--ask__ it will ask for confirmation on any change/modification/delete actions.

``` shell
~/environment $ cloudformation-deployer -h
usage: cloudformation-deployer [-h] [--ask] [--ignore-role-arn]
                               folder [folder ...]

CEPSA CLI to deploy cloudformation templates.

positional arguments:
  folder             list of template folders in order that contain the
                     Cloudformation and params files to deploy

optional arguments:
  -h, --help         show this help message and exit
  --ask              this flag will ask for confirmation on every deploy
  --ignore-role-arn  this flag will unset the rolearn param of the
                     deployments, so CF will inherit the current user IAM role
                     to perform the deployment, this should be used for
                     admin/platform deployments only
  --region           use with value us-east-1 if you need to deploy infra in North Virginia
  --jenkins_inputs   use this list to include input parameters using Jenkins. Example: --jenkins_inputs param1=param1value ... param2=param2value
```

You can use the cloudformation-deployer in two ways:
    
1. You can create a folder (i.e. iac folder) that contains a __config.yml__ and a __template.yml__ (cf template). In this example the application/lambda code can be put in the __code__ folder or elsewhere, but must be referenced in the corresponding CF template.
    
``` shell
~/environment/cloudformation-deployer/iac (master) $ tree
.
├── alarms-sns-topics
│   ├── config.yml
│   └── template.yml
└── lambda
    ├── code
    │   └── lambda_function.py
    ├── config.yml
    └── template.yml

```

To invoke cloudformation you must specify the folder __alarms-sns-topics__ if you want to deploy that stack, or the __lambda__ folder to deploy that other stack. cloudformation-deployer will automatically will search for the config.yml and template.yml files and used them if they exist on the input folder.

2. Another way to use cloudformation-deployer is to pass the full path to the config.yml (which can be named in any way) and this file can contain the property __TemplateFilename__ that specifies the templates to be used. In no TemplateFile is passed then its assumed by default that the file template.yml should be present. This means that you can deploy a single template with multiple configurations if needed, you just need to rename the config files as appropiate.
``` shell
~/environment/cloudformation-deployer/iac (master) $ tree
.
└──  lambda
    ├── code
    │   └── lambda_function.py
    ├── config-one.yml
    ├── config-two.yml
    └── template.yml
```

and the the deployer can be used as follows

``` bash
$ cloudformation-deployer lambda/config-one.yml
or
$ cloudformation-deployer lambda/config-two.yml
```

Here is complete example of a __config.yml__ file:

```yaml
# Stackname is mandatory
StackName: test-cloudwatch-alarms

# This optional property indicates the matching template file for the current config.yml, by default the value its "template.yml" if the property is not specified
TemplateFilename: template.yml

# Package is not mandatory, but if you CF template includes transforms like Serverless, you must set it to True
Package: False

# Optional
StackOptions:
    # DisableRollback its only used if its the first deploy
    DisableRollback: True
    EnableTerminationProtection: True

# Mappings between cf exports and template params
ExportParamMappings:
    #TeplateParam: CloudformationExportName
    Environment: Platform--Environment--Name
    VPCId: VPC--Id
    PrivateSubnet1: PrivateSubnet1--Id
    PrivateSubnet2: PrivateSubnet2--Id
    CustomIAMRoleServiceTokenArn: Custom--IamCreateRoleFunction--Arn
    AuroraSecurityGroupId: RDS--Aurora--SecurityGroupId
    AuroraSecretManager: RDS--Aurora--SecretManager
    #Mappings for specific environments
    dev:
        AlarmSNSTopicHigh: SNSAlarmsteam--Arn
        AlarmSNSTopicMedium: SNSAlarmsteam--Arn
        AlarmSNSTopicLow: SNSAlarmsteam--Arn
    qa:
        AlarmSNSTopicHigh: SNSAlarmsteam--Arn
        AlarmSNSTopicMedium: SNSAlarmsteam--Arn
        AlarmSNSTopicLow: SNSAlarmsteam--Arn
    pro:
        AlarmSNSTopicHigh: Platform--SNS--OpsAlarmsHigh--Arn
        AlarmSNSTopicMedium: Platform--SNS--OpsAlarmsMedium--Arn
        AlarmSNSTopicLow: Platform--SNS--OpsAlarmsLow--Arn

# Params that are dependant of environment, but are not exported and stored anywhere else, use case is are (i.e.) for InstanceTypes that you want to be a small size in dev and a bigger size in prod. Can also be used to store parameters such as external URLS dependant of environments.
# Var Selection is done in a automatic way based on the value of Cloudformation Export: Platform--Environment--Name
EnvironmentParamMappings:
    #Global param
    Ec2Param: Value
    #Specific Params
    dev:
        #TemplateParam: value
        Ec2InstanceType: m4.medium
    qa:
        #TemplateParam: value
        Ec2InstanceType: m4.medium
    pro:
        #TemplateParam: value
        Ec2InstanceType: m4.xlarge

# Parameters that are not exported by CF templates, this is an specific use of outputs of CF that are not exported.
OutputParamMappings:
    - StackName: platform-child-iam-baseline
      OutputName: ExportPlatformEnvironmentName
      ParamName: Environment

# This will ask for the specified params and pass them to the CF template invocation, usefull for informatino like passwords from onpremise instances and sensible that should not be hardcored in the deployment scripts.
# If the UsePreviousValue is set to True, cloudformation-deployer will only ask for it on the first (create) deploy.
UserInputParamMappings:
    - ParamName: SQLPassword
    - ParamName: OraclePassword
      UsePreviousValue: True

#Implemented
# Use to get a value from a resource in a stack that is not available as output
# For example, lambda@edge version arn in a stack in NV to use it in CloudFront
DescribeParamMappings:
    - StackName: lambda-edge-stack-name
      ResourceType : AWS::Lambda::Version
      ResourceValue: PhysicalResourceId
      ParamName: pLambdaEdgeArn
      Region: us-east-1

# Nested template URIs
# This feature calculates an URI for a required nested template, in this example with name __Param1Url__ and __Param2Url__
NestedTemplateLocations:
    dev:
        Bucket: cf-templates-XXXXXXXXX-eu-west-1
        Templates:
            Param1Url: my_nested_template1.yml
    Bucket: cf-templates-XXXXXXXXX-eu-west-1
    Templates:
        Param2Url: nest2/my_nested_template2.yml

# Read encrypted and unencrypted params from ParameterStore and pass them to CF template parameters.
# Note: If you are going to use this feature, your own role must have privileges to get parameters from system manager
ParameterStoreMappings:
    ParamName1: parameter-store-name-1
    ParamName2: encrypted-parameter-store-name
    dev:
        ParamName3: parameter-store-name-2

# DEPRECATED: Better, use dynamic references: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/dynamic-references.html
# Read secrets from Secrets Manager and pass them to CF template parameters.
# Note: If you are going to use this feature, your own role must have privileges to get the secrets from secrets manager
#SecretsManagerMappings:
#    ParamName1: secret-name-1
#    ParamName2: secret-name-2
#    dev:
#        ParamName3: secret-name-3

# If specific capabilities are needed, you can specify them here
Capabilities:
    - CAPABILITY_IAM
    - CAPABILITY_NAMED_IAM
    - CAPABILITY_AUTO_EXPAND


# By default 7 tags are included in all the stacks with values from cf-exports and other calculated values:
# { 'Key': 'environment', 'Value': cf_exports['Platform--Environment--Name'] },
# { 'Key': 'owner', 'Value': cf_exports['Platform--Owner--Name'] },
# { 'Key': 'trail', 'Value': cf_exports['Platform--Trail--Name'] },
# { 'Key': 'git_commit', 'Value': current git commit of the template file repo },
# { 'Key': 'git_branch', 'Value': current active git branch },
# { 'Key': 'git_url', 'Value': repo git url },
# { 'Key': 'deployer_account', 'Value': user id of the deployer to address him/her easily }
# In the Tags section you can include any extra tags you need
Tags:
    - Key: tag1
      Value: test1
    - Key: tag4
      Value: test5

Conditions:
    # to use this conditions cloudformation-deployer -c condname12 folder1
    condname12:
        # these Keys will be overwritten in the main template, only this five tags are supported
        ExportParamMappings:
            .....
        EnvironmentParamMappings:
            ....
        OutputParamMappings:
            .....
        UserInputParamMappings:
            .....
        Tags:
            .....

# Optional, it uploads the file/folder to s3 as a MD5_filename MD5_folder.zip in the uri i.e. s3://PackageBucket/s3Uploader/STACKNAME/MD5_filename
# both bucket and key path can be changed. In addition, the keypath and the completeuri can be passed as parameters to the template
s3Uploader:
    - RelativePath: path/to/my/filename
      BucketName: myBucketName    # Optional, if bucket change between environments you can use BucketNameCFExport instead (check last example)
      KeyPath: myKeyPathNameInS3  # Optional
      BucketNameAsParam: myBucketNameRef  # This option can only be used along with KeyPathAsParam
      KeyPathAsParam: myParamName
    - AbsolutePath: /complete/path/to/my/folder
      KeyPathAsParam: myParamName  # the key path can be used referencing it as !Ref myParamName in the template
    - RelativePath: path/to/my/folder
      BucketNameCFExport: myCFExportName  # i.e. LandingBucket--Name
      CompleteUriAsParam: mys3Uri    # the complete uri param can be used referencing it as !Ref mys3Uri in the template
```

# Demo

There is a demo recorded with [__asciinema__](https://asciinema.org/) on the file demo.cast. After installing asciinema just do a:

``` shell
$ asciinema play demo.cast
```


# How to perform the test locally

    docker run -it --rm -v $(pwd):/tmp/unitest_ci:ro python:3.6.8 bash
    # Inside docker container
    cd /tmp/unitest_ci && python3 -m pip install -r requirements.txt && python3 -m pip install -r test/requirements.txt && export PYTHONPATH=${PYTHONPATH}:$(pwd) && python3 test/test_auxiliary_methods.py

# Changelog

- 1.0.1 validations of stackname, yaml malformed and config.yml and template.yml files
- 1.0.2 add argparse for validation of parameters
- 1.0.3 add ask flags to confirm user input of modifications of stacks
- 1.0.4 add __diff__ before deployment to compare resources that required replacement
- 1.0.5 support to map cf exports to template parameters __ExportParamMappings__
- 1.0.6 support to send enviroment specific variables with __EnvironmentParamMappings__
- 1.0.7 support to input values (password during execution)
- 1.0.8 support to read values not exported from CF outputs __OutputParamMappings__
- 1.0.9 capabilities support
- 1.0.10 StasckOptions done
- 1.0.11 better error handling on main update/create loop detection
- 1.0.12 added url to review changeset in AWS web console
- 1.0.13 added flag ___--ignore_role_arn___ to deploy platform components and not use the defaulta deployer
- 1.0.14 support for boto credentials caches
- 1.0.15 support for short name params & conditions
- 1.0.16 including spinners and reduce verbose mode
- 1.0.17 creating class and renaming all methods and global variables as instance properties.
- 1.0.18 add more tags (git commit, branch, url and deployer account if available) for better management
- 1.0.19 add feature for uploading files to s3 from template
- 1.1.1 improve s3Updater, pass bucket name as a named parameter to the template
- 1.1.2 adding fix for qa-dev-pro tags on ExportParamMappings
- 1.1.3 adding GitlabCI default env variables for tags
- 1.1.4 adding support for parameter store encrypted and added cf deployer version as tag
- 1.1.5 adding support nested templates s3 uploads as template params
- 1.1.6 improve support for import some methods
- 1.1.7 add new tag to upload s3 files to a bucket specified as cloud formation export name (BucketNameCFExport)
- 1.1.8 fix issue when uploading a file to s3 that does not exists previously (s3 client and s3 resource were created from different sessions and exception where not catch)
- 1.1.9 minor fix that adds a the column target and fix on dryrun
- 1.1.10 addding suport to deploy multiple config files with a single template, with the property TemplateFilename. 
Include DescribeParamMappings to be able to deploy lambda@edge. Include region us-east-1 support.
- 1.1.11 Include git url and git branch to use from Jenkins
- 1.1.12 Include jenkins_inputs subcommnad to deploy input user parameters using Jenkins
- 1.1.13 Support for SecretManager, but better use dynamic resolvers https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/dynamic-references.html
- 1.1.14 Support for different environments using OutputParamMappings
- 1.1.15 Bugfix with = characters with jenkins_inputs
- 1.1.16 Adding no-tags option to ignore platform tags