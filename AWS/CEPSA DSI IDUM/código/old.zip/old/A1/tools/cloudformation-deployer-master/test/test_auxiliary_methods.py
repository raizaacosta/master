#! /bin/python3  # Expected to update PYTHONPATH to run the test
import hashlib
import shutil
import unittest
import os
from unittest import mock
import boto3
from moto import mock_s3
from botocore.stub import Stubber

from cloudformation_deploy import ColorPrint, s3_uploader

test_folder_path = os.path.join(os.path.dirname(__file__), "source", "test_folder")
test_folder_path_zipped = os.path.join(os.path.dirname(__file__), "source", "test_folder.zip")

shutil.make_archive("/tmp/deleteme", 'zip', test_folder_path)
with open("/tmp/deleteme.zip", 'rb') as _f:                        # Depending on the OS/container/machine it creates differently a folder
    hash_folder = hashlib.md5(_f.read()).hexdigest()               #  therefore the checksum will be different and it has to be calculated dynamically

folder_with_checksum = hash_folder + "_test_folder.zip"
test_folder_path_with_checksum = os.path.join("/", "tmp", folder_with_checksum)

test_file_path = os.path.join(os.path.dirname(__file__), "source", "test")
hash_file = "fc5e038d38a57032085441e7fe7010b0"
filename_with_checksum = hash_file + "_test"
test_file_path_with_checksum = os.path.join("/", "tmp", filename_with_checksum)

bucket_name = "s3_uploader_test"
specified_key = "my/key/path/to/object"

generated_key_for_file = 's3Uploader/unittest/' + filename_with_checksum
generated_key_for_folder = 's3Uploader/unittest/' + folder_with_checksum


class TestAuxiliaryFunctions(unittest.TestCase):

    @mock.patch.object(ColorPrint, 'logger', create=True, return_value=None)
    def test_s3_uploader_returned_values(self, logger_mock):
        s3_client = boto3.client('s3')
        stubber_client = Stubber(s3_client)

        # Testing file upload
        s3_object_mock = mock.Mock()
        with open(test_file_path, 'rb') as _f:
            data = _f.read()
            s3_object_mock.read.side_effect = [data, data, data]

            stubber_client.add_response(method='get_object', service_response={'Body': s3_object_mock},
                                        expected_params={"Bucket": bucket_name, "Key": specified_key})

            stubber_client.add_client_error(method='get_object', service_error_code='NoSuchKey',
                                            expected_params={"Bucket": bucket_name, "Key": generated_key_for_file})

            stubber_client.add_response(method='put_object', service_response={},
                                        expected_params={'Body': data, 'Bucket': bucket_name, 'Key': generated_key_for_file})

            stubber_client.add_response(method='get_object', service_response={'Body': s3_object_mock},
                                        expected_params={"Bucket": bucket_name, "Key": generated_key_for_file})

        with stubber_client:
            # Uploads a file already uploaded with specific key, only get_object required
            result1 = s3_uploader(absolute_path=test_file_path, bucket_name=bucket_name, upload_id="",
                                  complete_key_path=specified_key, s3_client=s3_client, my_color_print=logger_mock)

            self.assertEqual(result1["KeyPath"], specified_key)
            self.assertEqual(result1["BucketName"], bucket_name)
            self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, specified_key))

            # Uploads a file not uploaded without specific key, get_object fail and put_object required
            result1 = s3_uploader(absolute_path=test_file_path, bucket_name=bucket_name, upload_id="unittest",
                                  complete_key_path=None, s3_client=s3_client, my_color_print=logger_mock)

            self.assertEqual(result1["KeyPath"], generated_key_for_file)
            self.assertEqual(result1["BucketName"], bucket_name)
            self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_file))

            # Uploads a file already uploaded without specific key, only get_object required
            result1 = s3_uploader(absolute_path=test_file_path, bucket_name=bucket_name, upload_id="unittest",
                                  complete_key_path=None, s3_client=s3_client, my_color_print=logger_mock)

            self.assertEqual(result1["KeyPath"], generated_key_for_file)
            self.assertEqual(result1["BucketName"], bucket_name)
            self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_file))

        # Testing folder upload
        s3_object_mock = mock.Mock()
        with open("/tmp/deleteme.zip", 'rb') as _f:
            data = _f.read()
            s3_object_mock.read.side_effect = [data, data, data]

            stubber_client.add_response(method='get_object', service_response={'Body': s3_object_mock},
                                        expected_params={"Bucket": bucket_name, "Key": specified_key})

            stubber_client.add_client_error(method='get_object', service_error_code='NoSuchKey',
                                            expected_params={"Bucket": bucket_name, "Key": generated_key_for_folder})

            stubber_client.add_response(method='put_object', service_response={},
                                        expected_params={'Body': data, 'Bucket': bucket_name, 'Key': generated_key_for_folder})

            stubber_client.add_response(method='get_object', service_response={'Body': s3_object_mock},
                                        expected_params={"Bucket": bucket_name, "Key": generated_key_for_folder})

        with stubber_client:
            # Uploads a file already uploaded with specific key, only get_object required
            result1 = s3_uploader(absolute_path=test_folder_path, bucket_name=bucket_name, upload_id="",
                                  complete_key_path=specified_key, s3_client=s3_client, my_color_print=logger_mock)

            self.assertEqual(result1["KeyPath"], specified_key)
            self.assertEqual(result1["BucketName"], bucket_name)
            self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, specified_key))

            # Uploads a file not uploaded without specific key, get_object fail and put_object required
            result1 = s3_uploader(absolute_path=test_folder_path, bucket_name=bucket_name, upload_id="unittest",
                                  complete_key_path=None, s3_client=s3_client, my_color_print=logger_mock)

            self.assertEqual(result1["KeyPath"], generated_key_for_folder)
            self.assertEqual(result1["BucketName"], bucket_name)
            self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_folder))

            # Uploads a file already uploaded without specific key, only get_object required
            result1 = s3_uploader(absolute_path=test_folder_path, bucket_name=bucket_name, upload_id="unittest",
                                  complete_key_path=None, s3_client=s3_client, my_color_print=logger_mock)

            self.assertEqual(result1["KeyPath"], generated_key_for_folder)
            self.assertEqual(result1["BucketName"], bucket_name)
            self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_folder))

    @mock_s3  # In this method s3 should be mocked with moto
    @mock.patch.object(ColorPrint, 'logger', create=True, return_value=None)
    def test_s3_uploader_uploaded_objects(self, logger_mock):
        mocked_s3 = boto3.client('s3', region_name='eu-west-1')
        self.assertEqual(len(mocked_s3.list_buckets()["Buckets"]), 0)
        mocked_s3.create_bucket(Bucket=bucket_name)
        self.assertEqual(len(mocked_s3.list_buckets()["Buckets"]), 1)
        ####
        # Testing a file
        ####

        # Uploads a file not uploaded with a specific key, get_object fail and put_object required
        with self.assertRaises(mocked_s3.exceptions.NoSuchKey):
            mocked_s3.get_object(Bucket=bucket_name, Key=specified_key)

        result1 = s3_uploader(absolute_path=test_file_path, bucket_name=bucket_name, upload_id=None,
                              complete_key_path=specified_key, s3_client=mocked_s3, my_color_print=logger_mock)

        self.assertEqual(result1["KeyPath"], specified_key)
        self.assertEqual(result1["BucketName"], bucket_name)
        self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, specified_key))
        self.assertEqual(hashlib.md5(mocked_s3.get_object(Bucket=bucket_name, Key=specified_key)["Body"].read()).hexdigest(),
                         hash_file)

        # Uploads a file not uploaded without specific key, get_object fail and put_object required
        with self.assertRaises(mocked_s3.exceptions.NoSuchKey):
            mocked_s3.get_object(Bucket=bucket_name, Key=generated_key_for_file)

        result1 = s3_uploader(absolute_path=test_file_path, bucket_name=bucket_name, upload_id="unittest",
                              complete_key_path=None, s3_client=mocked_s3, my_color_print=logger_mock)

        self.assertEqual(result1["KeyPath"], generated_key_for_file)
        self.assertEqual(result1["BucketName"], bucket_name)
        self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_file))
        self.assertEqual(hashlib.md5(mocked_s3.get_object(Bucket=bucket_name, Key=generated_key_for_file)["Body"].read()).hexdigest(),
                         hash_file)

        # Uploads a file already uploaded without specific key, only get_object required
        result1 = s3_uploader(absolute_path=test_file_path, bucket_name=bucket_name, upload_id="unittest",
                              complete_key_path=None, s3_client=mocked_s3, my_color_print=logger_mock)

        self.assertEqual(result1["KeyPath"], generated_key_for_file)
        self.assertEqual(result1["BucketName"], bucket_name)
        self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_file))
        self.assertEqual(hashlib.md5(mocked_s3.get_object(Bucket=bucket_name, Key=generated_key_for_file)["Body"].read()).hexdigest(),
                         hash_file)

        ####
        # Testing a folder
        ####
        # Uploads a file already uploaded with specific key, only get_object required
        mocked_s3.delete_object(Bucket=bucket_name, Key=specified_key)
        with self.assertRaises(mocked_s3.exceptions.NoSuchKey):
            mocked_s3.get_object(Bucket=bucket_name, Key=specified_key)

        result1 = s3_uploader(absolute_path=test_folder_path, bucket_name=bucket_name, upload_id="",
                              complete_key_path=specified_key, s3_client=mocked_s3, my_color_print=logger_mock)

        self.assertEqual(result1["KeyPath"], specified_key)
        self.assertEqual(result1["BucketName"], bucket_name)
        self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, specified_key))
        self.assertEqual(hashlib.md5(mocked_s3.get_object(Bucket=bucket_name, Key=specified_key)["Body"].read()).hexdigest(),
                         hash_folder)

        # Uploads a file not uploaded without specific key, get_object fail and put_object required
        with self.assertRaises(mocked_s3.exceptions.NoSuchKey):
            mocked_s3.get_object(Bucket=bucket_name, Key=generated_key_for_folder)

        result1 = s3_uploader(absolute_path=test_folder_path, bucket_name=bucket_name, upload_id="unittest",
                              complete_key_path=None, s3_client=mocked_s3, my_color_print=logger_mock)

        self.assertEqual(result1["KeyPath"], generated_key_for_folder)
        self.assertEqual(result1["BucketName"], bucket_name)
        self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_folder))
        self.assertEqual(hashlib.md5(mocked_s3.get_object(Bucket=bucket_name, Key=generated_key_for_folder)["Body"].read()).hexdigest(),
                         hash_folder)

        # Uploads a file already uploaded without specific key, only get_object required
        result1 = s3_uploader(absolute_path=test_folder_path, bucket_name=bucket_name, upload_id="unittest",
                              complete_key_path=None, s3_client=mocked_s3, my_color_print=logger_mock)

        self.assertEqual(result1["KeyPath"], generated_key_for_folder)
        self.assertEqual(result1["BucketName"], bucket_name)
        self.assertEqual(result1["CompleteUri"], "s3://{}/{}".format(bucket_name, generated_key_for_folder))
        self.assertEqual(hashlib.md5(mocked_s3.get_object(Bucket=bucket_name, Key=generated_key_for_folder)["Body"].read()).hexdigest(),
                         hash_folder)


if __name__ == '__main__':
    unittest.main()
