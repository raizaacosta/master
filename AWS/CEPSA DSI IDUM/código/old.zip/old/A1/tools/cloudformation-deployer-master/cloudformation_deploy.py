#!/usr/bin/env python3
import os
import hashlib
import shutil
import subprocess
import texttable as tt
import sys
import argparse
import logging
import yaml
import os
import datetime
import string
import random
import getpass
import time
import git
import botocore.session
from botocore import credentials
import boto3
import urllib.parse

CFD_VERSION = '1.1.16'

class ColorPrint:
    def __init__(self, log_level, name="cloudformation-v"+CFD_VERSION):
        self.logger = logging.Logger(name=name, level=log_level)
        streamer = logging.StreamHandler()
        streamer.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        self.logger.addHandler(streamer)

    def print_fail(self, message):
        self.logger.error('\x1b[1;31m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), message.strip()))
        self.logger.error('\x1b[1;31mEnd deploy process.\x1b[0m')
        sys.exit(-1)

    def print_pass(self, message):
        self.logger.warning('\x1b[1;32m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), message.strip()))

    def print_warn(self, message):
        self.logger.warning('\x1b[1;33m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), message.strip()))

    def print_info(self, message):
        self.logger.info('\x1b[1;34m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), message.strip()))

    def print_debug(self, message):
        self.logger.debug('\x1b[1;30m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), message.strip()))

    def print_bold(self, message):
        self.logger.info('\x1b[1;37m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), message.strip()))

    def print_exception(self, exception):
        self.logger.exception('\x1b[1;31m{} {} \x1b[0m'.format(datetime.datetime.utcnow(), exception))


def s3_uploader(absolute_path: str, bucket_name: str, upload_id: str, complete_key_path: str = None,
                s3_client=boto3.client("s3"), my_color_print=ColorPrint(logging.DEBUG)):
    """
    Uploads a file or a folder to the designated location in zip format. It checks the MD5 sum so it will not upload
    the same file twice, in that case, it notifies that is already uploaded.
    If no complete key path is provided a generated path is used with the value s3Uploader/UPLOAD_ID/MD5_BASEFILENAME.zip
    and the last basefilename is obtained from the absolute path.
    :return: A dictionary with the keys KeyPath, BucketName, CompleteUri (s3) and status (specifies if it was uploaded)
    """

    my_color_print.print_debug("Compressing file '{}'".format(absolute_path))
    new_file_path = os.path.join("/tmp", os.path.basename(absolute_path))
    unique_file_name = shutil.make_archive(new_file_path, 'zip', absolute_path) \
        if os.path.isdir(absolute_path) else shutil.copy(absolute_path, new_file_path)
    with open(unique_file_name, 'rb') as _f:
        local_hash = hashlib.md5(_f.read()).hexdigest()
    file_path_with_checksum = shutil.copy(unique_file_name,
                                          os.path.join(os.path.dirname(unique_file_name),
                                                       local_hash + "_" + os.path.basename(unique_file_name)))

    complete_key_path = os.path.join("s3Uploader", upload_id, os.path.basename(file_path_with_checksum)) \
        if not complete_key_path else complete_key_path

    s3_uri = "s3://{}/{}".format(bucket_name, complete_key_path)

    s3_file_parameters = {"KeyPath": complete_key_path,
                          "BucketName": bucket_name,
                          "CompleteUri":  s3_uri}

    try:
        s3_object = s3_client.get_object(Bucket=bucket_name, Key=complete_key_path)
        s3_hash = hashlib.md5(s3_object["Body"].read()).hexdigest()
        if local_hash == s3_hash:
            my_color_print.print_info("File(s) '{}' are already updated in s3 under the uri '{}'".format(absolute_path, s3_uri))
            s3_file_parameters["status"] = "Already uploaded with s3_hash(e-tag) {}".format(s3_hash)
            return s3_file_parameters
    except s3_client.exceptions.NoSuchKey:
        my_color_print.print_debug("File(s) '{}' are going to be uploaded to s3".format(absolute_path))

    try:
        with open(file_path_with_checksum, 'rb') as data:
            s3_client.put_object(Body=data.read(), Bucket=bucket_name, Key=complete_key_path)
    except Exception as ex:
        my_color_print.print_exception(str(ex))
        my_color_print.print_fail("Error when trying to upload to bucket '{}' with key name '{}'".format(bucket_name,
                                                                                                         complete_key_path))

    my_color_print.print_info("Uploaded zip to " + s3_uri)

    s3_file_parameters["status"] = "New object s3_hash(e-tag) {}".format(local_hash)
    return s3_file_parameters


def create_tags_from_git_repo_if_exists_in(path, my_color_print=ColorPrint(logging.DEBUG)):

    git_commit = os.getenv('CI_COMMIT_SHORT_SHA', 'No repo nor commit was found')
    git_branch = os.getenv('CI_COMMIT_REF_NAME',  os.getenv('BRANCH_NAME',  'No active branch was found'))
    git_url = os.getenv('CI_PROJECT_URL', os.getenv('GIT_URL', 'No remote url was found'))
    try:
        repo = git.Repo(path, search_parent_directories=True)
        git_commit = repo.commit().hexsha
        if (not os.getenv('GIT_URL') or not os.getenv('BRANCH_NAME')): #Only if it not deployed from Jenkins
            git_branch = repo.active_branch.name
            git_url = repo.remotes.origin.url \
                if "@" not in repo.remotes.origin.url else "https://" + repo.remotes.origin.url.split("@")[1]
            git_url = urllib.parse.unquote(git_url)
    except Exception as ex:
        my_color_print.print_warn(
            message="Repo was either not created or only local. Path provided: {}. Error: {}".format(path, ex))
        my_color_print.print_warn(message="Assigning dummy value as tag.")

    return [{'Key': 'git_commit', 'Value': git_commit},
            {'Key': 'git_branch', 'Value': git_branch},
            {'Key': 'git_url', 'Value': git_url}]


def get_deployer_account_name(my_color_print=ColorPrint(logging.DEBUG)):
    account_name = "Not enough permission to access 'sts' service"
    try:
        account_name = boto3.client('sts').get_caller_identity().get("UserId")
    except Exception as ex:
        my_color_print.print_warn(message="It was not possible to retrieve the UserId. Error: {}".format(ex))

    return [{'Key': 'deployer_account', 'Value': account_name}]


class CfDeployer:
    
    def __init__(self, args, log_level=logging.DEBUG):
        
        # Change the cache path from the default of ~/.aws/boto/cache to the one used by awscli
        working_dir = os.path.join(os.path.expanduser('~'), '.aws/cli/cache')
        
        # Construct botocore session with cache
        self.session = botocore.session.get_session()
        
        if args.region:
            self.session.set_config_variable('region', args.region)

        provider = self.session.get_component('credential_provider').get_provider('assume-role')
        provider.cache = credentials.JSONFileCache(working_dir)
        
        # Create boto3 client from session
        self.session = boto3.Session(botocore_session=self.session)
        self.cloudformation_client = self.session.client('cloudformation')

        self.args = args
        self.cf_exports = self.fetch_cloudformation_exports(my_cf=self.cloudformation_client, list_exports_params={},region=self.args.region)
        self.color_print = ColorPrint(log_level)
    
    def render_value(self, value):
        return str(value)
    
    def random_string(self, min_char=8, max_char=12):
        allchar = string.ascii_letters + string.digits
        return "".join(random.choice(allchar) for x in range(random.randint(min_char, max_char)))
    
    def query_yes_no(self, question, default="no"):
        valid = {"yes": True, "y": True, "ye": True,
                 "no": False, "n": False}
        if default is None:
            prompt = " [y/n] "
        elif default == "yes":
            prompt = " [Y/n] "
        elif default == "no":
            prompt = " [y/N] "
        else:
            raise ValueError("invalid default answer: '%s'" % default)
    
        while True:
            sys.stdout.write(question + prompt + "\n")
            choice = input().lower()
            if default is not None and choice == '':
                return valid[default]
            elif choice in valid:
                return valid[choice]
            else:
                sys.stdout.write("Please respond with 'yes' or 'no' "
                                 "(or 'y' or 'n').\n")

    @staticmethod
    def fetch_cloudformation_exports(my_cf, list_exports_params={}, region=None):
        local_cf_exports = {}
        end_of_exports = False
        list_exports_params = {}
        if region:
            results_west = boto3.client('cloudformation', region_name='eu-west-1').list_exports()
            while not end_of_exports:
                for export in results_west['Exports']:
                    local_cf_exports[export['Name']] = export['Value']
                    if 'NextToken' in results_west:
                        list_exports_params['NextToken'] = results_west['NextToken']
                    else:
                        end_of_exports = True
        
        end_of_exports = False
        results = my_cf.list_exports(**list_exports_params)
        while not end_of_exports:
            results = my_cf.list_exports(**list_exports_params)
            for export in results['Exports']:
                local_cf_exports[export['Name']] = export['Value']
            if 'NextToken' in results:
                list_exports_params['NextToken'] = results['NextToken']
            else:
                end_of_exports = True
        return local_cf_exports
    
    def parse_configuration(self, template_folder, config_yaml, is_create_stack, is_conditions, config_filename, template_filename):

        if not is_conditions:
            if is_create_stack:
                self.color_print.print_info('===Deploying {} from {}==='.format(config_yaml['StackName'], template_filename))
            else:
                self.color_print.print_info('===Create Stacket {} from {}==='.format(config_yaml['StackName'], template_filename))
        self.color_print.print_info('===Calculating param values from exports===')
        cf_exports = self.fetch_cloudformation_exports(my_cf=self.cloudformation_client, list_exports_params={}, region=self.args.region)
        stack_params = []
        stack_args = {}

        if 'NestedTemplateLocations' in config_yaml:
            for key in config_yaml['NestedTemplateLocations'].keys():
                if key in ['dev', 'qa', 'pro'] and key == cf_exports['Platform--Environment--Name']:
                    if 'Bucket' in config_yaml['NestedTemplateLocations'][key] and 'Templates' in config_yaml['NestedTemplateLocations'][key]:
                        for nt_key in config_yaml['NestedTemplateLocations'][key]['Templates'].keys():
                            self.color_print.print_pass('Nested template param {} detected.'.format(nt_key))
                            self.color_print.print_pass('Uploading template {} for param {} detected'.format(config_yaml['NestedTemplateLocations'][key]['Templates'][nt_key],nt_key))
                            dot_char_location = config_yaml['NestedTemplateLocations'][key]['Templates'][nt_key].rfind('.')
                            base_name = config_yaml['NestedTemplateLocations'][key]['Templates'][nt_key][:dot_char_location]
                            datetime_string_sufix = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                            calculated_path = '{}/{}.yml'.format(base_name, datetime_string_sufix)
                            full_calculated_uri = 'https://s3-eu-west-1.amazonaws.com/{}/{}'.format(config_yaml['NestedTemplateLocations']['Bucket'], calculated_path)
                            self.color_print.print_pass('uploading to {}'.format(full_calculated_uri) )
                            s3_client = boto3.client('s3')
                            response = s3_client.upload_file(template_folder+'/'+config_yaml['NestedTemplateLocations'][key]['Templates'][nt_key], config_yaml['NestedTemplateLocations'][key]['Bucket'], calculated_path)
                            param={}
                            param['ParameterKey'] = nt_key
                            param['ParameterValue'] = full_calculated_uri
                            stack_params.append(param)
                    else:
                        self.color_print.print_fail('No valid Bucket or Templates properties found in NestedTemplateLocations')

            if 'Bucket' in config_yaml['NestedTemplateLocations'] and 'Templates' in config_yaml['NestedTemplateLocations']:
                for nt_key in config_yaml['NestedTemplateLocations']['Templates'].keys():
                    self.color_print.print_pass('Nested template param {} detected.'.format(nt_key))
                    self.color_print.print_pass('Uploading template {} for param {} detected'.format(config_yaml['NestedTemplateLocations']['Templates'][nt_key],nt_key))
                    dot_char_location = config_yaml['NestedTemplateLocations']['Templates'][nt_key].rfind('.')
                    base_name = config_yaml['NestedTemplateLocations']['Templates'][nt_key][:dot_char_location]
                    datetime_string_sufix = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
                    calculated_path = '{}/{}.yml'.format(base_name, datetime_string_sufix)
                    full_calculated_uri = 'https://s3-eu-west-1.amazonaws.com/{}/{}'.format(config_yaml['NestedTemplateLocations']['Bucket'], calculated_path)
                    #full_calculated_uri = 's3://{}/{}'.format(config_yaml['NestedTemplateLocations']['Bucket'], calculated_path)
                    self.color_print.print_pass('uploading to {}'.format(full_calculated_uri) )
                    s3_client = boto3.client('s3')
                    response = s3_client.upload_file(template_folder+'/'+config_yaml['NestedTemplateLocations']['Templates'][nt_key], config_yaml['NestedTemplateLocations']['Bucket'], calculated_path)
                    param={}
                    param['ParameterKey'] = nt_key
                    param['ParameterValue'] = full_calculated_uri
                    stack_params.append(param)
            else:
                self.color_print.print_fail('No valid Bucket or Templates properties found in NestedTemplateLocations')

        if 'ExportParamMappings' in config_yaml:
            for key in config_yaml['ExportParamMappings'].keys():
                if key in ['dev', 'qa', 'pro']:
                    if key == cf_exports['Platform--Environment--Name']:
                        for key_map in  config_yaml['ExportParamMappings'][cf_exports['Platform--Environment--Name']].keys():
                            param={}
                            param['ParameterKey'] = key_map
                            param['ParameterValue'] = self.render_value(cf_exports[config_yaml['ExportParamMappings'][cf_exports['Platform--Environment--Name']][key_map]])
                            stack_params.append(param)
                            self.color_print.print_pass('Adding param {} from export {}'.format(key_map, param['ParameterValue']))
    
                elif config_yaml['ExportParamMappings'][key] in cf_exports:
                    self.color_print.print_pass('{} is {}'.format(key, cf_exports[config_yaml['ExportParamMappings'][key]]))
                    param={}
                    param['ParameterKey'] = key
                    param['ParameterValue'] = self.render_value(cf_exports[config_yaml['ExportParamMappings'][key]])
                    stack_params.append(param)
                else:
                    self.color_print.print_fail('ERROR: export "{}" doesn\'t exist'.format(config_yaml['ExportParamMappings'][key]))

        if 'EnvironmentParamMappings' in config_yaml:
            for key in config_yaml['EnvironmentParamMappings'].keys():
                if key in ['dev', 'qa', 'pro']:
                    if key == cf_exports['Platform--Environment--Name']:
                        for key in config_yaml['EnvironmentParamMappings'][cf_exports['Platform--Environment--Name']].keys():
                            param={}
                            param['ParameterKey'] = key
                            param['ParameterValue'] = self.render_value(config_yaml['EnvironmentParamMappings'][cf_exports['Platform--Environment--Name']][key])
                            stack_params.append(param)
                else:
                    self.color_print.print_pass('{} is {}'.format(key, config_yaml['EnvironmentParamMappings'][key]))
                    param={}
                    param['ParameterKey'] = key
                    param['ParameterValue'] = self.render_value(config_yaml['EnvironmentParamMappings'][key])
                    stack_params.append(param)
                    
        if 'OutputParamMappings' in config_yaml:
            print(type(config_yaml['OutputParamMappings']))
            if type(config_yaml['OutputParamMappings']) == dict:
                for key in config_yaml['OutputParamMappings'].keys():
                    if key in ['dev', 'qa', 'pro']:
                        if key == cf_exports['Platform--Environment--Name']:
                            for output_yaml_item in config_yaml['OutputParamMappings'][cf_exports['Platform--Environment--Name']]:
                                response_outputpar = self.cloudformation_client.describe_stacks(
                                    StackName=output_yaml_item['StackName']
                                )
                                if len(response_outputpar['Stacks']) == 1:
                                    found_output = False
                                    found_item = None
                                    for outputitem in response_outputpar['Stacks'][0]['Outputs']:
                                        if outputitem['OutputKey'] == output_yaml_item['OutputName']:
                                            found_item = outputitem
                                            found_output = True
                                            break
                                    if found_output:
                                        param={}
                                        param['ParameterKey'] =  output_yaml_item['ParamName']
                                        param['ParameterValue'] = self.render_value(found_item['OutputValue'])
                                        stack_params.append(param)
                                        self.color_print.print_pass('Output "{}" found for stack "{}"'.format(output_yaml_item['OutputName'], output_yaml_item['StackName']))
                                    else:
                                        self.color_print.print_fail('Could not find output "{}" for stack "{}"'.format(output_yaml_item['OutputName'], output_yaml_item['StackName']))
                                else:
                                    self.color_print.print_fail('Invalid stackname or output name "{}" for stack "{}"'.format(output_yaml_item['OutputName'], output_yaml_item['StackName']))
            else:
                for output_yaml_item in config_yaml['OutputParamMappings']:
                    response_outputpar = self.cloudformation_client.describe_stacks(
                        StackName=output_yaml_item['StackName']
                    )
                    if len(response_outputpar['Stacks']) == 1:
                        found_output = False
                        found_item = None
                        for outputitem in response_outputpar['Stacks'][0]['Outputs']:
                            if outputitem['OutputKey'] == output_yaml_item['OutputName']:
                                found_item = outputitem
                                found_output = True
                                break
                        if found_output:
                            param={}
                            param['ParameterKey'] =  output_yaml_item['ParamName']
                            param['ParameterValue'] = self.render_value(found_item['OutputValue'])
                            stack_params.append(param)
                            self.color_print.print_pass('Output "{}" found for stack "{}"'.format(output_yaml_item['OutputName'], output_yaml_item['StackName']))
                        else:
                            self.color_print.print_fail('Could not find output "{}" for stack "{}"'.format(output_yaml_item['OutputName'], output_yaml_item['StackName']))
                    else:
                        self.color_print.print_fail('Invalid stackname or output name "{}" for stack "{}"'.format(output_yaml_item['OutputName'], output_yaml_item['StackName']))

        if 'DescribeParamMappings' in config_yaml:
            for output_yaml_item in config_yaml['DescribeParamMappings']:
                if output_yaml_item['Region']:
                    response_outputpar = boto3.client('cloudformation', region_name=output_yaml_item['Region']).describe_stack_resources(
                        StackName=output_yaml_item['StackName']
                    )
                else:
                    response_outputpar = self.cloudformation_client.describe_stack_resources(
                        StackName=output_yaml_item['StackName']
                    )
                if len(response_outputpar['StackResources']) > 0:
                    found_output = False
                    found_item = None
                    for outputitem in response_outputpar['StackResources']:
                        if outputitem['ResourceType'] == output_yaml_item['ResourceType']:
                            found_item = outputitem
                            found_output = True
                            break
                    if found_output:
                        param={}
                        param['ParameterKey'] =  output_yaml_item['ParamName']
                        param['ParameterValue'] = self.render_value(found_item[output_yaml_item['ResourceValue']])
                        stack_params.append(param)
                        self.color_print.print_pass('Resource "{}" found for stack "{}"'.format(output_yaml_item['ResourceType'], output_yaml_item['StackName']))
                    else:
                        self.color_print.print_fail('Could not find resource "{}" for stack "{}"'.format(output_yaml_item['ResourceType'], output_yaml_item['StackName']))
                else:
                    self.color_print.print_fail('Invalid stackname or resource type "{}" for stack "{}"'.format(output_yaml_item['ResourceType'], output_yaml_item['StackName']))
                    
        if ('UserInputParamMappings' in config_yaml) and not self.args.jenkins_inputs: #Without Jenkins
            self.color_print.print_info('Please input the parameter values for the current stack ({})'.format(config_yaml['StackName']))
            for inputkey in config_yaml['UserInputParamMappings']:
                if not is_create_stack and 'UsePreviousValue' in inputkey and inputkey['UsePreviousValue']:
                    param={}
                    param['ParameterKey'] = inputkey['ParamName']
                    param['UsePreviousValue'] = True
                    stack_params.append(param)
                else:
                    p = getpass.getpass(prompt='Input value for "{}: '.format(inputkey['ParamName']))
                    self.color_print.print_pass('Value for "{}" captured succesfully.'.format(inputkey))
                    param={}
                    param['ParameterKey'] = inputkey['ParamName']
                    param['ParameterValue'] = self.render_value(p)
                    stack_params.append(param)
                    
        if ('UserInputParamMappings' in config_yaml) and self.args.jenkins_inputs: #With Jenkins
            print('UserInputParamMappings with Jenkins')
            for inputkey in config_yaml['UserInputParamMappings']:
                if not is_create_stack and 'UsePreviousValue' in inputkey and inputkey['UsePreviousValue']:
                    param={}
                    param['ParameterKey'] = inputkey['ParamName']
                    param['UsePreviousValue'] = True
                    stack_params.append(param)
                else:
                    for pair_input in self.args.jenkins_inputs:
                        splitted = pair_input.split('=')
                        parameter_name = splitted[0]
                        parameter_value = '='.join(splitted[1:])
                        param={}
                        param['ParameterKey'] = parameter_name
                        param['ParameterValue'] = parameter_value
                        stack_params.append(param)        

        if 'ParameterStoreMappings' in config_yaml:
            for key in config_yaml['ParameterStoreMappings'].keys():
                if key in ['dev', 'qa', 'pro']:
                    if key == cf_exports['Platform--Environment--Name']:
                        for key_map in  config_yaml['ParameterStoreMappings'][cf_exports['Platform--Environment--Name']].keys():
                            param={}
                            param['ParameterKey'] = key_map
                            ssm_client = boto3.client('ssm')
                            response_parameter_store = ssm_client.get_parameter(
                                Name=config_yaml['ParameterStoreMappings'][key][key_map],
                                WithDecryption=True
                            )
                            param['ParameterValue'] = response_parameter_store['Parameter']['Value']
                            stack_params.append(param)
                            self.color_print.print_pass('Adding param {} from parameter store {}'.format(key_map, config_yaml['ParameterStoreMappings'][key][key_map]))
                else:
                    self.color_print.print_pass('searching for {}'.format(config_yaml['ParameterStoreMappings'][key]))
                    param={}
                    param['ParameterKey'] = key
                    ssm_client = boto3.client('ssm')
                    response_parameter_store = ssm_client.get_parameter(
                        Name=config_yaml['ParameterStoreMappings'][key],
                        WithDecryption=True
                    )
                    param['ParameterValue'] = response_parameter_store['Parameter']['Value']
                    stack_params.append(param)

        if 'SecretsManagerMappings' in config_yaml:
            for key in config_yaml['SecretsManagerMappings'].keys():
                if key in ['dev', 'qa', 'pro']:
                    if key == cf_exports['Platform--Environment--Name']:
                        for key_map in  config_yaml['SecretsManagerMappings'][cf_exports['Platform--Environment--Name']].keys():
                            param={}
                            param['ParameterKey'] = key_map
                            secrets_client = boto3.client('secretsmanager')
                            response_parameter_store = secrets_client.get_secret_value(
                                SecretId=config_yaml['SecretsManagerMappings'][key][key_map]
                            )
                            param['ParameterValue'] = response_parameter_store['SecretString']
                            stack_params.append(param)
                            self.color_print.print_pass('Adding param {} from secrets manager {}'.format(key_map, config_yaml['SecretsManagerMappings'][key][key_map]))
                else:
                    self.color_print.print_pass('searching for {}'.format(config_yaml['SecretsManagerMappings'][key]))
                    param={}
                    param['ParameterKey'] = key
                    secrets_client = boto3.client('secretsmanager')
                    response_parameter_store = secrets_client.get_secret_value(
                        SecretId=config_yaml['SecretsManagerMappings'][key]
                    )
                    param['ParameterValue'] = response_parameter_store['SecretString']
                    stack_params.append(param)

        if not self.args.no_platform_tags and not self.args.ignore_role_arn:
            tag_list = [{'Key': 'deployer_version', 'Value': CFD_VERSION },
                        {'Key': 'environment', 'Value': cf_exports['Platform--Environment--Name']},
                        {'Key': 'owner', 'Value': cf_exports['Platform--Owner--Name']},
                        {'Key': 'trail', 'Value': cf_exports['Platform--Trail--Name']},
                        ] + create_tags_from_git_repo_if_exists_in(path=template_folder, my_color_print=self.color_print) + \
                       get_deployer_account_name(my_color_print=self.color_print)

        else:
            tag_list = []
    
        if 'Tags' in config_yaml:
            for tag in config_yaml['Tags']:
                if 'Key' in tag and 'Value' in tag:
                    self.color_print.print_pass('adding tag {} = {}'.format(tag['Key'], tag['Value']))
                    tag_list.append(tag)
                else:
                    self.color_print.print_fail('wrong tags key names')
        self.color_print.print_info('tags used on this deployment are: {}'.format(tag_list))
        template_file_name = ''
        if not self.args.region:
            lambda_bucket_name = config_yaml['NonTemplateParams']['LambdaFunctionsBucket--Name'] if 'LambdaFunctionsBucket--Name' not in cf_exports else cf_exports['LambdaFunctionsBucket--Name']
        if self.args.region and self.args.region == 'us-east-1':
            lambda_bucket_name = config_yaml['NonTemplateParams']['LambdaEdgeBucket--Name'] if 'LambdaEdgeBucket--Name' not in cf_exports else cf_exports['LambdaEdgeBucket--Name']

        if 'Package' in config_yaml and config_yaml['Package']:
            command = ['aws', 'cloudformation', 'package', '--template-file', '{}'.format(template_filename), '--s3-bucket', lambda_bucket_name, '--s3-prefix', config_yaml['StackName'], '--output-template-file', '{}/packaged.yml'.format(template_folder)]

            subprocess.run(command)
            template_file_name = '{}/packaged.yml'.format(template_folder)
            self.color_print.print_info('setting capabilities')
            stack_args['Capabilities'] = ['CAPABILITY_AUTO_EXPAND', 'CAPABILITY_NAMED_IAM', 'CAPABILITY_IAM']
        else:
            template_file_name = '{}'.format(template_filename)

        if 's3Uploader' in config_yaml and config_yaml['s3Uploader']:
            for path in config_yaml['s3Uploader']:
                unexpected_keys = [key for key in path if key not in
                                   ["RelativePath", "BucketName", "KeyPath", "BucketNameAsParam",
                                    "KeyPathAsParam", "AbsolutePath", "BucketNameCFExport", "CompleteUriAsParam"]]
                if unexpected_keys:
                    self.color_print.print_fail("Error in s3Uploader. In item {}. ".format(path) +\
                                                "Unexpected keys {}".format(unexpected_keys))
                if "AbsolutePath" in path:
                    absolute_path = os.path.abspath(path["AbsolutePath"])
                else:
                    absolute_path = os.path.abspath(os.path.join(template_folder, path["RelativePath"]))

                if "BucketName" in path and "BucketNameCFExport" in path:
                    self.color_print.print_fail("Error in s3Uploader. In item {}. ".format(path) +\
                                                "BucketName and BucketNameCFExport can not be declared at the same time")
                if "BucketName" in path:
                    bucket_name = path["BucketName"]
                elif "BucketNameCFExport" in path:
                    bucket_name = cf_exports[path["BucketNameCFExport"]]
                    if not bucket_name:
                        self.color_print.print_fail("Error in s3Uploader. In item {}. ".format(path) +\
                                                    "BucketNameCFExport contains an invalid value '{}'".format(bucket_name))
                else:
                    bucket_name = lambda_bucket_name

                result = s3_uploader(absolute_path=absolute_path, s3_client=self.session.client("s3"), bucket_name=bucket_name,
                                     complete_key_path=None if "KeyPath" not in path else path["KeyPath"],
                                     upload_id=config_yaml['StackName'], my_color_print=self.color_print)

                if "KeyPathAsParam" in path:
                    stack_params.append({"ParameterKey": path["KeyPathAsParam"], "ParameterValue": result["KeyPath"]})
                    if "BucketNameAsParam" in path:
                        stack_params.append({"ParameterKey": path["BucketNameAsParam"], "ParameterValue": result["BucketName"]})
                elif "CompleteUriAsParam" in path:
                    stack_params.append({"ParameterKey": path["CompleteUriAsParam"], "ParameterValue": result["CompleteUri"]})
                else:
                    self.color_print.print_fail("Error in s3Uploader. In item {}. ".format(path) +\
                                                "Missing 'KeyPathAsParam' or 'CompleteUriAsParam' tags (only one required).")

        if 'Capabilities' in config_yaml:
            if len(config_yaml['Capabilities']) > 0:
                stack_args['Capabilities'] = config_yaml['Capabilities']
    
        return { 'stack_args': stack_args, 'stack_params': stack_params, 'template_file_name': template_file_name, 'tag_list':tag_list }
    
    def deploy_stack(self, template_folder, config_yaml, is_create_stack, stack_args, stack_params, template_file_name, tag_list):
    
        if 'StackOptions' in config_yaml:
            for key_arg in  config_yaml['StackOptions']:
                if 'EnableTerminationProtection' == key_arg:
                    if is_create_stack:
                        stack_args[key_arg] = config_yaml['StackOptions'][key_arg]
                    else:
                        self.color_print.print_info('Updating termination protection to {}'.format(config_yaml['StackOptions'][key_arg]))
                        response = self.cloudformation_client.update_termination_protection(
                            EnableTerminationProtection=config_yaml['StackOptions'][key_arg],
                            StackName=config_yaml['StackName']
                        )
                elif 'DisableRollback' == key_arg:
                    if is_create_stack:
                        stack_args[key_arg] = config_yaml['StackOptions'][key_arg]
                        #we do nothing in else
    
        with open(template_file_name, 'r') as template_file_object:
            template_data=template_file_object.read()
            #self.color_print.print_info('template body is:')
            #print(template_data)
            stack_id = ''
            if is_create_stack:
                # This will not set hte CloudformationServiceRoleDeployer used for admin/platform deployments
                if not self.args.ignore_role_arn:
                    stack_args['RoleARN'] = self.cf_exports['CloudformationServiceRoleDeployer--Arn']
                response_create_stack = self.cloudformation_client.create_stack(
                    StackName=config_yaml['StackName'],
                    TemplateBody=template_data,
                    Parameters=stack_params,
                    Tags=tag_list,
                    **stack_args
                )
                stack_id = response_create_stack['StackId']
            else:
                stack_set_hash = self.random_string()
                stack_set_date = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                change_set_name = 'change-{}-{}'.format(stack_set_date, stack_set_hash)
                if not self.args.ignore_role_arn:
                    stack_args['RoleARN'] = self.cf_exports['CloudformationServiceRoleDeployer--Arn']
                result_create_change_set = self.cloudformation_client.create_change_set(
                    ChangeSetName=change_set_name,
                    ChangeSetType='UPDATE',
                    StackName=config_yaml['StackName'],
                    TemplateBody=template_data,
                    Parameters=stack_params,
                    Tags=tag_list,
                    **stack_args
                )
    
                self.color_print.print_info('waiting for changeset {} to be completed'.format(change_set_name))
                response_create_change_set = None
                while True:
                    time.sleep(3)
                    response_create_change_set = self.cloudformation_client.describe_change_set(
                        ChangeSetName=change_set_name,
                        StackName=config_yaml['StackName']
                    )
                    if 'FAILED' == response_create_change_set['Status']:
                        self.color_print.print_warn('changet set has FAILED')
                        non_critical_reasons = ['The submitted information didn\'t contain changes. Submit different information to create a change set.',
                                               'No updates are to be performed.']
                        if response_create_change_set['StatusReason'] in non_critical_reasons:
                            self.color_print.print_warn(response_create_change_set['StatusReason'])
                            return
                        else:
                            self.color_print.print_fail('ERROR {}'.format(response_create_change_set['StatusReason']))
    
                    if 'CREATE_COMPLETE' == response_create_change_set['Status']:
                        self.color_print.print_pass('changet set ready to be deployed')
                        break
                ascii_tab = tt.Texttable()
                table_headings = ['Action','LogicalResourceId','PhysicalResourceId', 'Replacement', 'Target']
                ascii_tab.header(table_headings)
                #print(response_create_change_set['Changes'])
                for change_ob in response_create_change_set['Changes']:
                    c = change_ob['ResourceChange']
                    row_object = []
                    row_object.append(c['Action'])
                    row_object.append(c['LogicalResourceId'])
                    row_object.append(c['PhysicalResourceId'] if 'PhysicalResourceId' in c else '')
                    row_object.append(c['Replacement'] if 'Replacement' in c else '')
                    target_str = ''
                    for target in c['Details']:
                        if 'Properties' == target['Target']['Attribute'] and 'Name' in target['Target']:
                            target_str+=target['Target']['Name']+'\n'
                        else:
                            target_str+=target['Target']['Attribute']+'\n'
                    row_object.append(target_str)
                    ascii_tab.add_row(row_object)
                self.color_print.print_pass('Review the changeset check this url:')
                url_string = 'https://{}.console.aws.amazon.com/cloudformation/home?region={}#/changeset/detail?changeSetId={}&stackId={}'.format(self.session.region_name, self.session.region_name, result_create_change_set['Id'], result_create_change_set['StackId'])
                self.color_print.print_pass('{}'.format(url_string))
                self.color_print.print_info('Changes detected are:')
                table_string = ascii_tab.draw()
                print(table_string)
                
                if self.args.dryrun:
                    self.color_print.print_pass("Deleting change set.")
                    response = self.cloudformation_client.delete_change_set(
                        ChangeSetName=change_set_name,
                        StackName=config_yaml['StackName']
                    )
                    self.color_print.print_pass("Dry run finished.")
                    sys.exit(0)
    
                if self.args.ask:
                    if not self.query_yes_no('Do you want to deploy this changes?'):
                        self.color_print.print_fail('Change set execution aborted by user.')
                response_execute_change_set = self.cloudformation_client.execute_change_set(
                    ChangeSetName=change_set_name,
                    StackName=config_yaml['StackName']
                )
                response_describe_stack = self.cloudformation_client.describe_stacks(StackName=config_yaml['StackName'])
                stack_id = response_describe_stack['Stacks'][0]['StackId']
    
            self.color_print.print_info('waiting for stack changes {} to be completed'.format(stack_id))

            flapInitial = True
    
            while True:
                response_describe_stack = self.cloudformation_client.describe_stacks(StackName=stack_id)
                stack_creation_status = response_describe_stack['Stacks'][0]['StackStatus']
                if stack_creation_status in ['CREATE_COMPLETE', 'UPDATE_COMPLETE']:
                    self.color_print.print_pass('{} current status is {}'.format(stack_id, stack_creation_status))
                    self.color_print.print_pass('Stack {} deployment finished'.format(template_folder))
                    break
                elif stack_creation_status.endswith('COMPLETE'):
                    self.color_print.print_warn('{} current status is {}'.format(stack_id, stack_creation_status))
                    self.color_print.print_fail('Something went wrong, aborting deployment.')
                    print('https://{}.console.aws.amazon.com/cloudformation/home?region={}#/stack/detail?stackId={}'.format(self.session.region_name, self.session.region_name, stack_id))
                    break
                elif stack_creation_status.endswith('FAILED'):
                    self.color_print.print_fail('{} status is {}'.format(stack_id ,stack_creation_status))
                    break
    
                if flapInitial:
                    flapInitial = False

                self.color_print.print_info('current status is {}'.format(stack_creation_status))
                time.sleep(15)

    def get_template_path(self, template_folder, conf_filename):
        stream = open('{}'.format(conf_filename), 'r')
        config_yaml_original = yaml.safe_load(stream)
        if 'TemplateFilename' not in config_yaml_original:
            self.color_print.print_pass('no TemplateFilename property found in {}, selecting name "template.yml" as default.'.format(conf_filename))

            if isinstance(template_folder, list):
                temp_filename = '/'.join(template_folder + ["template.yml"])
            else:
                temp_filename = '/'.join([template_folder] + ["template.yml"])
            print(temp_filename)
            if not os.path.isfile(temp_filename):
                self.color_print.print_fail('ERROR: templatefile "{}" doesn\'t exists'.format(temp_filename))
        else:
            file_path_arr = template_folder.split('/')
            file_path_arr[-1]=config_yaml_original['TemplateFilename']
            temp_filename = '/'.join(file_path_arr)
            if not os.path.isfile(temp_filename):
                self.color_print.print_fail('ERROR: templatefile "{}" doesn\'t exists'.format(temp_filename))  
        return temp_filename

    def main(self):
        self.color_print.print_info('cloudformation-deployer version: {}'.format(CFD_VERSION))
        
        self.color_print.print_bold('===Cloudformation Base Parameters===')
        if not self.args.ignore_role_arn:
            base_params = ['CloudformationServiceRoleDeployer--Arn',
                           'Platform--Environment--Name',
                           'Platform--Owner--Name',
                           'Platform--Trail--Name',
                           'LambdaFunctionsBucket--Name']
        else:
            base_params = []

        for base_param in base_params:
            self.color_print.print_info('{} is {}'.format(base_param, self.cf_exports[base_param]))
        self.color_print.print_bold('===Checking if template folders exists and have template and config files===')
        for template_folder in self.args.template_folders:
            
            conf_filename = ''
            temp_filename = ''
            
            if os.path.isdir(template_folder):
                self.color_print.print_pass('PASS: folder "{}" exists, selecting default filename for config.yml'.format(template_folder))
                trimmed = template_folder.rstrip("/")
                conf_filename = '{}/config.yml'.format(trimmed)
                temp_filename = self.get_template_path(trimmed, conf_filename)

            elif os.path.isfile(template_folder):
                self.color_print.print_pass('PASS: config file detected "{}".'.format(template_folder))
                self.color_print.print_info('Reading template TemplateFilename from config.')
                conf_filename = template_folder
                file_path_arr = template_folder.split('/')
                if len(file_path_arr) == 1:
                    template_folder = "."
                else:
                    template_folder = '/'.join(file_path_arr[0:-1])
                temp_filename = self.get_template_path(template_folder, conf_filename)

            else:
                self.color_print.print_fail('ERROR: folder "{}" doesn\'t exists'.format(template_folder))

            if os.path.exists('{}'.format(conf_filename)):
                self.color_print.print_pass('PASS: file "{}" exists.'.format(conf_filename))
            else:
                self.color_print.print_fail('ERROR: file "{}" doesn\'t exists'.format(conf_filename))
            stream = open('{}'.format(conf_filename), 'r')
            config_yaml_original = yaml.safe_load(stream)
            if 'StackName' in config_yaml_original:
                self.color_print.print_pass('PASS: Stackname "{}" configured for "{}"'.format(config_yaml_original['StackName'],template_folder))
            else:
                self.color_print.print_fail('ERROR: Missing "StackName" element in "{}"'.format(conf_filename))

            if os.path.exists('{}'.format(temp_filename)):
                self.color_print.print_pass('PASS: file "{}" exists.'.format(temp_filename))
                self.color_print.print_info('template validation started')
                template_body = open('{}'.format(temp_filename), 'r')
                response_template_validation = self.cloudformation_client.validate_template(
                    TemplateBody=template_body.read()
                )
                self.color_print.print_pass('PASS: valid template "{}" exists.'.format(temp_filename))
            else:
                self.color_print.print_fail('ERROR: file "{}" doesn\'t exists'.format(temp_filename))

            self.color_print.print_bold('===Deploying templates===')
#        for template_folder in self.args.template_folders:
            stream = open('{}'.format(conf_filename), 'r')
            # config_yaml_original = yaml.safe_load(stream, Loader=yaml.FullLoader)
            config_yaml_original = yaml.safe_load(stream)
            self.color_print.print_info('===Checking if stack "{}" exists for {}==='.format(config_yaml_original['StackName'], temp_filename))
            is_create_stack = True
            try:
                response = self.cloudformation_client.describe_stacks(StackName=config_yaml_original['StackName'])
                self.color_print.print_pass('Stack {} exists'.format(config_yaml_original['StackName']))
                is_create_stack = False
            except botocore.exceptions.ClientError:
                self.color_print.print_warn('WARN: stack "{}" doesn\'t exists'.format(config_yaml_original['StackName']))
                is_create_stack = True
                if self.args.dryrun:
                    self.color_print.print_pass("Dry run finished.")
                    sys.exit(0)

            result_parse = self.parse_configuration(template_folder, config_yaml_original, is_create_stack, False, conf_filename, temp_filename)

            if self.args.condition_name is not None:
                if 'Conditions' in config_yaml_original:
                    if self.args.condition_name in config_yaml_original['Conditions']:
                        result_parse_condition = self.parse_configuration(template_folder, config_yaml_original['Conditions'][self.args.condition_name], is_create_stack, True, conf_filename, temp_filename)
                        #print('PARSECONDITIONS {}'.format(result_parse_condition))
                        for spar in result_parse_condition['stack_params']:
                            param_found = False
                            for opar in result_parse['stack_params']:
                                if spar['ParameterKey'] == opar['ParameterKey']:
                                    param_found = True
                                    result_parse['stack_params'].remove(opar)
                                    result_parse['stack_params'].append(spar)
                            if not param_found:
                                result_parse['stack_params'].append(spar)
        
                        for stag in result_parse_condition['tag_list']:
                            tag_found = False
                            for otag in result_parse['tag_list']:
                                if stag['Key'] == otag['Key']:
                                    tag_found = True
                                    result_parse['tag_list'].remove(otag)
                                    result_parse['tag_list'].append(stag)
                            if not tag_found:
                                result_parse['tag_list'].append(stag)
                    else:
                        self.color_print.print_fail('can\'t find the {} in the config file'.format(self.args.condition_name))
        
            self.deploy_stack(template_folder, config_yaml_original, is_create_stack, result_parse['stack_args'],  result_parse['stack_params'], result_parse['template_file_name'], result_parse['tag_list'])
        
        self.color_print.print_pass('Deployment finished.')


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='CEPSA CLI to deploy cloudformation templates. Current version: {}'.format(CFD_VERSION))
    parser.add_argument('template_folders', metavar='folder', nargs='+',
                        help='list of template folders in order that contain the Cloudformation and params files to deploy')
    parser.add_argument('-a', '--ask', action='store_true', help='this flag will ask for confirmation  on every deploy')
    parser.add_argument('-i', '--ignore-role-arn', action='store_true',
                        help='this flag will unset the rolearn param of the deployments, so CF will inherit the current user IAM role to perform the deployment, this should be used for admin/platform deployments only')
    parser.add_argument('-c', '--condition', dest='condition_name', type=str,
                        help='condition name to overwrite the params of the main template')
    parser.add_argument('-region', '--region', dest='region', type=str,
                        help='indicates region. Only valid for eu-west-1')
    parser.add_argument('-d', '--dryrun', action='store_true', help='Dry run, create changeset but dont execute it.')
    parser.add_argument('--jenkins_inputs', nargs='+',
                        help='Pairs key=value for InputParamMapping used from Jenkins')
    parser.add_argument('-n','--no-platform-tags', action='store_true',
                        help='this flag will disable all the tags on the stack')

    args = parser.parse_args()

    dep = CfDeployer(args)

    try:
        dep.main()
    except Exception as e:
        logging.exception(str(e))
        ColorPrint(logging.DEBUG).print_fail("Deployment has failed")
